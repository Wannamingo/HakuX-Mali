Unified P77r1 — testing release
6 November 2026

The exact release ELF passed the assigned native GPU/API checks on RG476H,
RG477M and Rotate. This local package is ready for testing and host-side
HakuX integration. See RELEASE-ACCEPTANCE.json for the exact admission scope.
New game FPS and long-session stability have not been established.

Installation

In an application supporting custom Vulkan driver ZIPs, import the package,
select Unified, fully close the game and restart it. A driver change may
rebuild the application's pipeline cache; assess first-run loading separately
from warmed operation. Select System and restart the game to switch back.

Requirements: ARM64, Android 12/API31 or later, and a compatible application
loader. One ELF contains separate Mali-G52, Mali-G57 and Mali-G615 paths.
Manual ZIP import does not guarantee GPU compatibility. Adreno needs a
different driver such as a compatible Turnip build. Mali-G76 and other
models rejected by this binary's hardware checks are not qualified here.

Changes

The existing MaliSX2-0.2.3-based Unified fixes are retained. Selected accepted
upstream changes through MaliSX2 0.3.3 add the G52 tiler heap limit fix,
adaptive JM tiler heap rings, linear descriptor pools with allocation rollback,
BGRA8/D24S8-plane AFBC, unused direct VS-to-FS output elimination, G57 weak
early kill, conservative primitive reorder, the G615 combined colour/depth
LOAD preload order, and unsupported BC1-7 format capability rejection.
P76's slice-aware 3D nearest blits and linear-Z interpolation are inherited.
These changes do not reduce game resolution.

Limits

G52/G57 advertise Vulkan 1.1. The current G615 branch advertises experimental
Vulkan 1.4. This release does not establish complete Vulkan 1.1-1.4 support
or Khronos conformance. Geometry/tessellation, complete descriptor indexing,
bindless resources and some external formats remain limited.

The public AHardwareBuffer/FOREIGN backend is restricted to G615 with a known
gralloc ABI. Full external RGB image handling uses an additional experimental
gate. G52/G57 retain narrower Android native-buffer handling. Import-only
tests do not qualify screen presentation. The private G57 depth/stencil blit
gate remains disabled by default.

Open MaliSX2 PRs for CPU descriptor mirrors, G52 BC, further barriers, PERMON,
vertex SSBO bounds checks and private bindless are not included. Mesa/compiler
sources remain frozen; this is a selective backport, not a complete rebase.

Consult the release matrix for tested devices and firmware. Other firmware
and applications require separate checks. Native test counts are not game
FPS, frame-pacing or long-session stability measurements.

Driver ZIP: metadata, libvulkan_malisx2.so, licences and limits. Driver/Mesa
sources, full ELF, patches, checksums and test reports are supplied separately.
Distributed archives do not contain games, private settings or saved games.

Qualification

Each device passed six processes: 16-format BC capability policy, linear pool,
two attachment LOAD modes, repeated graphics and Android native-buffer metadata.
Across all three devices: 18 processes, including 9 with GPU work; 39 pool cases,
4395 allocated sets, 48 attachment cases / 786432 pixel coordinates, and
72 repeated graphics cases. A separate G615 private external RGB/AHB test passed
349527 checks including 200 BufferQueue frames. Raw results, ELF identity, thermal
gates, complete saved kernel windows and installation preservation were reviewed.
Rotate stock kernel evidence was extracted from an actual bugreport; private
application hashes are unavailable without root. Limited P76/P77 CTS pilots are
inherited evidence, not a full CTS run of P77r1.

Matrix

RG476H / Mali-G57 — GammaOS Next 1.2, Android 14.
RG477M / Mali-G615 MC6 — GammaOS Next 1.2.1, Android 14.
Rotate T618 / Mali-G52 — Anbernic stock V1.44, Android 12.
Other devices and firmware are outside this admission.
