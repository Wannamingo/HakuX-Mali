Unified P48r1 — RG476H and RG477M compatibility driver

Use the RG476H-JM package on RG476H with Android13/API33+, or RG477M-CSF on RG477M with Android14/API34+. HakuX-common contains the same ELF and should be offered only to these qualified device/API profiles.

Exit the game, import the ZIP through the HakuX GPU driver manager, select Unified, fully restart the app and then start the game. To revert, select the previous or system driver and restart the app. App-data deletion is unnecessary. This is an application-loaded Vulkan driver, not a system firmware update. These packages are not for Adreno.

COMPATIBILITY.json records tested capabilities, defaults and remaining limitations. Full Vulkan1.1–1.4 conformance and an FPS advantage over MaliSX2 are not claimed. A reported Vulkan API version is not a substitute for the qualification matrix.

Library SHA256: 71e520f9de773d23700b2a5e48e6960dbd588d791b3e6b0ef31f77b5d17330df
